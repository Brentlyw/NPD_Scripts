from flask import Flask, render_template, request
import sqlite3
from itertools import groupby

app = Flask(__name__)

# Function to connect to the SQLite database
def connect_db():
    conn = sqlite3.connect('MaineResidents.db')
    conn.row_factory = sqlite3.Row
    return conn

# Function to determine the completeness of a row
def row_completeness(row):
    completeness_score = sum(1 for key in row.keys() if row[key])  # Count non-empty fields
    return completeness_score

# Home route to search
@app.route('/', methods=['GET', 'POST'])
def index():
    conn = connect_db()
    cursor = conn.cursor()
    grouped_results = {}

    if request.method == 'POST':
        # Collect search criteria
        search_fields = ['firstname', 'lastname', 'middlename', 'ssn', 'city', 'county_name', 'zip']
        query_parts = []
        values = []
        for field in search_fields:
            value = request.form.get(field)
            if value:
                query_parts.append(f"{field} LIKE ?")
                values.append(f"%{value}%")
        
        if query_parts:
            query = f"SELECT * FROM records WHERE {' AND '.join(query_parts)}"
            cursor.execute(query, values)
            results = cursor.fetchall()
            
            # Sort and group results by SSN
            results = sorted(results, key=lambda x: x['ssn'])
            grouped_results = {}
            for ssn, group in groupby(results, key=lambda x: x['ssn']):
                unique_addresses = {}
                for row in group:
                    address = row['address']
                    if address not in unique_addresses:
                        unique_addresses[address] = row
                    else:
                        # Compare the completeness of the current row with the stored row
                        if row_completeness(row) > row_completeness(unique_addresses[address]):
                            unique_addresses[address] = row
                grouped_results[ssn] = list(unique_addresses.values())

    conn.close()
    return render_template('index.html', grouped_results=grouped_results)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
